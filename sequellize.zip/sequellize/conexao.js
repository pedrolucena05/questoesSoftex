const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
  dialect: 'mysql',
  host: 'localhost',  // Substitua pelo host do seu banco de dados
  username: 'root', // Substitua pelo nome de usuário do seu banco de dados
  password: '446123abb', // Substitua pela senha do seu banco de dados
  database: 'testando', // Substitua pelo nome do seu banco de dados
});

async function testarConexao() {
  try {
    await sequelize.authenticate();
    console.log('Conexão com o banco de dados estabelecida com sucesso.');
  } catch (error) {
    console.error('Erro ao conectar ao banco de dados:', error);
  }
}

testarConexao();

module.exports = sequelize;
